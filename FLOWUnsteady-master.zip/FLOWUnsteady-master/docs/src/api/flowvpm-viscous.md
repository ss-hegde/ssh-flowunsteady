# Viscous Scheme
```@docs
FLOWUnsteady.vpm.ViscousScheme
FLOWUnsteady.vpm.Inviscid
FLOWUnsteady.vpm.CoreSpreading
FLOWUnsteady.vpm.ParticleStrengthExchange
FLOWUnsteady.vpm.rbf_conjugategradient
```
