# SFS Scheme
```@docs
FLOWUnsteady.vpm.SubFilterScale
FLOWUnsteady.vpm.NoSFS
FLOWUnsteady.vpm.ConstantSFS
FLOWUnsteady.vpm.DynamicSFS
FLOWUnsteady.vpm.clipping_backscatter
FLOWUnsteady.vpm.control_directional
FLOWUnsteady.vpm.control_magnitude
FLOWUnsteady.vpm.dynamicprocedure_pseudo3level
FLOWUnsteady.vpm.dynamicprocedure_sensorfunction
FLOWUnsteady.vpm.Estr_direct
FLOWUnsteady.vpm.Estr_fmm
FLOWUnsteady.vpm.Estr_direct
FLOWUnsteady.vpm.Estr_direct
```
