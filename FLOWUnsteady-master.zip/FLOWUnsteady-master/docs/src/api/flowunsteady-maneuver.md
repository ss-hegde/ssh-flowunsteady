# (2) Maneuver Definition
```@docs
FLOWUnsteady.KinematicManeuver
FLOWUnsteady.DynamicManeuver

FLOWUnsteady.plot_maneuver
FLOWUnsteady.visualize_kinematics
```
